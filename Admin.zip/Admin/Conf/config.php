<?php
return array(
	//'配置项'=>'配置值'
	'USER_AUTH_KEY'=>'fdR32DKL',
	'CAR_PAGE_COUNT'=>'20',
	'CARPOINT_PAGE_COUNT'=>'20',
	'USER_PAGE_COUNT'=>'20',
	'SCORE_PAGE_COUNT'=>'20',
);
?>
