<?php
class IndexModel extends Model{

}
